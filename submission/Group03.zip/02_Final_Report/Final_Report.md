<div class="cover">

# T01 - GUI & Usability Testing

## Reproducible User Guide for EShop Checkout

**Group 03 - CSC13003 Software Testing - 23KTPM4**  
**Traditional practice:** Manual UI testing with BrowserStack Live + usability study design with Maze  
**AI-augmented practice:** Screenshot review with Claude Vision, followed by mandatory human audit  
**System under test:** EShop checkout flow

**Demo video (YouTube Unlisted):** `VIDEO_LINK_REQUIRED`

| Student ID | Full name |
|---|---|
| 23127149 | Nguyễn Bình An |
| 23127027 | Phạm Ngọc Gia Bảo |
| 23127035 | Lee Kun Da |
| 23127327 | Lưu Ngô Quốc Bảo |

</div>

# Contents

**Responsible: 23127149 - Nguyễn Bình An**

1. Scope and learning outcomes
2. Tool pairing and rationale
3. Reproducible environment setup
4. Manual UI testing with BrowserStack Live
5. AI-assisted screenshot review and human audit
6. Maze usability study
7. Available evidence and limitations
8. Troubleshooting and failure modes
9. In-class activity: Heuristic Showdown
10. References
11. Appendices: submission traceability and final review

<div class="page-break"></div>

# Executive summary

**Responsible: 23127149 - Nguyễn Bình An**

A user interface can be functionally correct and still make users hesitate, misread feedback, or abandon checkout. This guide presents a two-layer approach for the EShop checkout flow. The first layer is human-led: testers inspect the interface across browsers and devices with BrowserStack Live and design a task-based usability study in Maze. The second layer is AI-assisted: Claude Vision reviews captured screenshots against visual-quality criteria and Nielsen's usability heuristics. Every AI finding passes through a human verification gate before it can become a defect.

The guide is intentionally reproducible. It documents environment preparation, task design, evidence capture, severity rules, a human-audit protocol, troubleshooting, and a 20-minute classroom activity. It also draws a strict boundary around the available evidence. The repository contains a Maze study draft and local screenshots of cart, coupon, and successful checkout states, but no exported participant results, response distributions, or verified BrowserStack defect set. Consequently, this report does not claim success rates, misclick rates, AI accuracy percentages, or validated defects that the source material cannot support.

The central lesson is practical: AI can widen the review surface and accelerate hypothesis generation, but people remain responsible for context, reproduction, severity, and the final decision.

# 1. Scope and learning outcomes

**Responsible: 23127149 - Nguyễn Bình An**

## 1.1 Scope

The seminar focuses on the customer checkout journey:

1. Review the cart.
2. Continue to checkout and authenticate if required.
3. Apply a coupon and interpret feedback.
4. Review the amount due.
5. Confirm payment and recognize the success state.

The guide covers manual visual inspection, cross-browser and cross-device review, screenshot-based heuristic review, human verification of AI suggestions, and task-based usability-study design. It does not claim to replace automated functional tests, accessibility conformance testing, production user research, or security testing.

## 1.2 Learning outcomes

After following the guide, a student should be able to:

- Create a focused browser/device matrix instead of testing random combinations.
- Run the EShop checkout flow locally and expose it safely to a remote test device.
- Record evidence with environment metadata and reproducible steps.
- Ask an AI vision model for structured heuristic-review hypotheses.
- Classify each AI suggestion as verified, rejected, or not testable from the available evidence.
- Design a Maze Free Explore scenario with neutral task wording and useful follow-up questions.
- Report limitations without converting a small or incomplete study into a broad claim.

# 2. Tool pairing and rationale

## 2.1 UI testing: BrowserStack Live + Claude Vision

**Responsible: 23127149 - Nguyễn Bình An**

BrowserStack Live supports hands-on inspection on remote browser and device combinations. It is useful for interaction states, responsive behavior, rendering differences, keyboard navigation, and issues that only appear in a real browser session. Claude Vision is used as a second reviewer of static screenshots. It can propose issues involving hierarchy, spacing, wording, consistency, and heuristic violations, but it cannot interact with the application or prove that an issue exists.

The pairing is deliberate:

| Human-led BrowserStack review | AI-assisted screenshot review |
|---|---|
| Observes hover, focus, scroll, loading, keyboard, and device behavior | Rapidly proposes visual and heuristic hypotheses |
| Reproduces an issue in a named environment | Helps identify areas a tester may want to inspect |
| Owns severity and defect decision | Does not own severity or the final verdict |

## 2.2 Usability testing: Maze

**Responsible: 23127027 - Phạm Ngọc Gia Bảo**

Maze provides a structured way to present a task, collect click evidence, and ask follow-up questions. The repository evidence shows a study draft for Group 03. The later guide on an unmerged branch proposes a single end-to-end Free Explore scenario because plan capabilities and available evidence do not support treating the draft as a full metric-rich usability experiment.

The study should be interpreted as exploratory class research. Heatmaps and question responses can reveal friction, but they do not automatically establish causality, represent all EShop customers, or prove that a design change is correct.

# 3. Reproducible environment setup

## 3.1 Start the EShop SUT

**Responsible: 23127327 - Lưu Ngô Quốc Bảo**

The project notes identify the following local components:

| Component | Folder | Expected URL |
|---|---|---|
| Backend API | `eshop-sut/backend` | `http://localhost:3000` |
| Customer frontend | `eshop-sut/frontend-web` | `http://localhost:5173` |
| Admin frontend, optional | `eshop-sut/frontend-admin` | `http://localhost:5174` |

Start the backend:

```bash
cd eshop-sut/backend
npm install
node database.js
node server.js
```

Start the customer frontend in a second terminal:

```bash
cd eshop-sut/frontend-web
npm install
npm run dev
```

Optional admin frontend:

```bash
cd eshop-sut/frontend-admin
npm install
npm run dev
```

Project notes list the test user `test@eshop.com` with password `Test1234!`. Treat these as local test credentials only. Re-check them against the current SUT documentation before use.

## 3.2 Seeded coupon cases

**Responsible: 23127327 - Lưu Ngô Quốc Bảo**

The existing guide records four seeded coupon cases:

| Code | Intended test purpose |
|---|---|
| `SAVE10` | Percentage discount with a minimum-order rule |
| `BIGBUY` | Fixed-value discount with a minimum-order rule |
| `VIP100` | Fixed-value discount with a usage limit |
| `EXPIRED` | Expired-coupon error state |

Because coupon rules and seed data can change, verify the active database before a live session. Reusing the same account may consume a limited coupon and change later participants' experience.

## 3.3 Remote access

**Responsible: 23127035 - Lee Kun Da**

For BrowserStack Live, use BrowserStack Local or another approved tunnel so the remote device can reach the local application. For a Maze participant study, use a public staging URL or a controlled prototype. Do not distribute a `localhost` URL: it points to each participant's own machine, not the presenter's SUT.

Before sharing a URL:

- Test it from an incognito browser and a second device.
- Remove real customer data, private keys, and course-secret information.
- Reset or isolate test accounts so participant behavior is comparable.
- Record the exact build, seed state, browser, device, and study version.

# 4. Manual UI testing with BrowserStack Live

**Responsible: 23127327 - Lưu Ngô Quốc Bảo**

## 4.1 Focused test matrix

Start with a small risk-based matrix:

| Platform | Browser/device | Main risk |
|---|---|---|
| Windows | Latest stable Chrome | Primary desktop rendering and interaction |
| Windows | Latest stable Firefox or Edge | Engine-specific CSS and focus behavior |
| macOS | Latest stable Safari | WebKit rendering |
| Android | A recent Samsung/Pixel device | Narrow viewport and virtual keyboard |
| iOS | A recent iPhone model | Mobile Safari, touch targets, viewport behavior |

Record exact versions at execution time. "Latest" is a planning label, not sufficient evidence in a defect report.

## 4.2 End-to-end inspection

For each selected environment:

1. Open the home page and add a seeded product.
2. Open the cart and inspect product name, price, quantity, total, removal action, and empty-state behavior.
3. Continue to checkout and authenticate if prompted.
4. Apply one valid and one invalid/expired coupon.
5. Verify whether feedback is visible, specific, and placed near the action.
6. Review the final amount and confirm payment using only test data.
7. Confirm that the success state is recognizable and offers a sensible next step.
8. Repeat with keyboard-only navigation on desktop and with touch on mobile.

Inspect:

- Alignment, spacing, wrapping, and overflow.
- Typography and visual hierarchy.
- Contrast and non-color cues.
- Focus, hover, active, disabled, loading, success, and error states.
- Touch-target size and virtual-keyboard obstruction.
- Consistency of totals and feedback across cart and checkout.

## 4.3 Evidence record

For every candidate issue, record:

| Field | Required content |
|---|---|
| ID | Stable identifier such as `UI-01` |
| Environment | OS, browser, version, device, viewport |
| Preconditions | Account and seed state |
| Steps | Minimal reproducible sequence |
| Expected | Observable expected behavior |
| Actual | Observable behavior, without speculation |
| Severity | Cosmetic, minor, major, or catastrophic |
| Evidence | Screenshot or short recording |
| Status | Candidate, verified, rejected, or fixed/retested |

# 5. AI-assisted screenshot review and human audit

**Responsible: 23127149 - Nguyễn Bình An**

## 5.1 Prompt protocol

Use a constrained prompt that asks for hypotheses, not authoritative defects:

> Review this EShop checkout screenshot as a hypothesis generator. Evaluate visual hierarchy, spacing, wording, contrast risk, feedback visibility, and Nielsen's usability heuristics. For every suggested issue, provide the screen location, the relevant heuristic, a tentative severity, what additional evidence is needed, and a recommended verification step. Do not claim a defect that cannot be established from the screenshot.

For desktop/mobile comparison:

> Compare these two screenshots of the same EShop state. List only visible differences. Separate likely defects from expected responsive changes. State when interaction, DOM, or contrast-measurement evidence is required.

Save the exact prompt, model/tool name, access date, input screenshots, output, and reviewer.

## 5.2 Human audit decision gate

**Responsible: 23127327 - Lưu Ngô Quốc Bảo**

Every AI suggestion receives one verdict:

| Verdict | Meaning | Required action |
|---|---|---|
| Verified | Reproduced in the named environment with supporting evidence | May enter the defect report |
| Rejected | The claimed issue is absent, expected, or based on a wrong assumption | Record why it was rejected |
| Needs evidence | Static screenshots cannot establish the claim | Run the required interaction, DOM, or measurement check |
| Duplicate | Same root issue already exists | Link to the original defect |

AI severity is advisory. The human reviewer assigns final severity based on task impact and reproducibility.

# 6. Maze usability study

**Responsible: 23127027 - Phạm Ngọc Gia Bảo**

## 6.1 Study design

Use one end-to-end Free Explore task so participants stay in the same checkout session:

> Add one product to the cart, continue to checkout, log in with the provided test account if prompted, apply the provided coupon, review the final amount, and confirm payment. Notice whether an address-confirmation step exists, then end the task.

Neutral wording matters. Do not tell participants exactly where to click or imply that the interface is correct.

## 6.2 Follow-up questions

**Responsible: 23127035 - Lee Kun Da**

Use a short sequence:

1. How clear was the feedback after applying the coupon? (1-5)
2. Where did you see shipping-address information? (Multiple choice, including "I did not see it")
3. After confirmation, were you confident that an order had been created? (Yes/No + optional reason)
4. How easy was the overall checkout flow? (1-5)
5. Which step required the most effort? (Multiple choice)
6. Which step was most confusing, and what one change would help most? (Open text)

Run a one- or two-person pilot before publishing. Confirm that the URL works, the seeded data is stable, questions appear in order, no real payment/personal data is requested, and the result view records the intended evidence.

## 6.3 Analysis rules

**Responsible: 23127027 - Phạm Ngọc Gia Bảo**

After collection:

- Report total and valid responses separately.
- State exclusion rules before filtering.
- Use heatmaps as click evidence, not as proof of user intent.
- Summarize rating distributions; do not report only an average.
- Group repeated open-text themes and retain contradictory feedback.
- Limit findings to what the data supports.
- Treat a class convenience sample as exploratory.

# 7. Available evidence and limitations

**Responsible: 23127027 - Phạm Ngọc Gia Bảo**

## 7.1 Evidence present in the repository

The repository contains local EShop self-check screenshots:

![Local cart self-check](../assets/eshop_cart.png)

*Figure 1. Local cart state used to prove that the checkout path was runnable. It is not a BrowserStack cross-device result.*

![Coupon feedback self-check](../assets/eshop_coupon.png)

*Figure 2. Local coupon success state using `BIGBUY`. It does not establish usability or cross-browser quality.*

![Successful checkout self-check](../assets/eshop_success.png)

*Figure 3. Local successful checkout state. It demonstrates a reachable completion state, not participant comprehension.*

The repository also contains a Maze study draft:

![Maze study draft](../assets/maze_study_draft.png)

*Figure 4. Draft block structure for Group 03. The screenshot explicitly labels the study as a draft and therefore cannot be treated as participant-result evidence.*

## 7.2 Claims intentionally not made

The available source material does not support:

- Maze success rate, completion time, misclick rate, or response distributions.
- A verified set of BrowserStack defects across named environments.
- Claude precision, recall, or a true-positive percentage.
- Fabricated participant comments, audience feedback, or attendance.

If the team has newer evidence, add it with dates, environment metadata, and source links before submission.

# 8. Troubleshooting and failure modes

**Responsible: 23127327 - Lưu Ngô Quốc Bảo**

| Failure mode | Symptom | Detection | Mitigation |
|---|---|---|---|
| Local tunnel unavailable | Remote BrowserStack device cannot load the SUT | Test the URL from the remote session before starting | Restart the tunnel, check ports/firewall, or use staging |
| Shared account changes state | Later testers receive different coupon behavior | Compare seed/account state between runs | Reset data or provide isolated accounts |
| AI invents hidden interaction problems | Claude describes hover, validation, or DOM behavior absent from the screenshot | Try to reproduce the claim | Mark "needs evidence" or reject |
| AI overstates contrast compliance | Output gives a ratio without sampling colors | Measure foreground/background with an approved checker | Record the measured ratio and method |
| Maze heatmap is overinterpreted | Click clusters are described as user intent | Compare with task wording and follow-up answers | Phrase as an observation, not a cause |
| Task wording teaches the solution | High apparent completion with little diagnostic value | Pilot with neutral wording | Remove interface labels and click instructions |
| Small convenience sample is generalized | Report claims to represent all customers | Inspect sample description and conclusion language | Label results exploratory and state limitations |

# 9. In-class activity: Heuristic Showdown

**Responsible: 23127149 - Nguyễn Bình An**

The companion `Activity_Worksheet` runs in 20 minutes:

1. Audience teams inspect an EShop screen and identify at least five potential issues.
2. Teams map each issue to a Nielsen heuristic and assign tentative severity.
3. The facilitator reveals an AI-generated draft containing both plausible and unsupported claims.
4. Teams audit each AI claim as verified, rejected, or needing more evidence.
5. The class compares what humans noticed, what AI proposed, and why evidence changes the verdict.

The activity is designed to work offline after the worksheet and screenshots are distributed.

# 10. References

**Responsible: 23127035 - Lee Kun Da**

1. Course materials: `Seminar_Guide.docx.pdf`, `Seminar_Workflow_Briefing.pptx.pdf`, `requirement/T01_GUI_and_Usability_Testing.docx`, `requirement/submission requirement.pdf`, and `requirement/q&a.pdf`.
2. BrowserStack Live documentation: <https://www.browserstack.com/docs/live>
3. BrowserStack Local documentation: <https://www.browserstack.com/docs/local-testing>
4. Maze Help Center: <https://help.maze.co/>
5. Nielsen Norman Group, "10 Usability Heuristics for User Interface Design": <https://www.nngroup.com/articles/ten-usability-heuristics/>
6. W3C, Web Content Accessibility Guidelines (WCAG) 2.1: <https://www.w3.org/TR/WCAG21/>
7. Anthropic documentation: <https://docs.anthropic.com/>

# Appendix A. Demo and submission traceability

**Responsible: 23127149 - Nguyễn Bình An**

- Demo video (YouTube Unlisted): `VIDEO_LINK_REQUIRED`
- Slide source: `01_Seminar_Slides/Seminar_Slides.md`
- AI Audit: `04_AI_Audit/AI_02_AI_Audit_Report.md`
- Contribution statement: `03_Project_Contribution/Project_Contribution_Statement.md`
- Activity worksheet: `05_Supplementary/Activity_Worksheet.md`

# Appendix B. Final human review checklist

**Responsible: All four members**

- [ ] Real YouTube Unlisted link appears in this report and the slides.
- [ ] Every section owner is correct.
- [ ] Current SUT commands, credentials, routes, and coupon data are re-checked.
- [ ] Any new study results are backed by exports/screenshots.
- [ ] No AI suggestion is presented as a defect without reproduction.
- [ ] All AI-03 disclosures are reviewed and signed by the named members.
- [ ] Contribution hours and percentages are confirmed by the team.
- [ ] Markdown and PDF versions match.
